This version of A4 SPEED FONT is completely free for personal use only.
For commercial purposes you must purchase a license.
The basic license costs USD12. You can make the payment in the link provided and then request the certificate by email to coki@outlook.com or by DM Instagram @a4speedfont

Payment for commercial use: https://www.paypal.me/a4grafica

Coki Fernandez. Rosario, Argentina, April 2022.


ESPAÑOL
Esta versión de A4 SPEED FONT es totalmente gratuita sólo para uso personal.
Para fines comerciales debe comprar una licencia.
La licencia básica tiene un costo de USD12. Puede realizar el pago en el link provisto y luego solicitar el certificado por email a coki@outlook.com o por DM Instagram @a4speedfont

Pago para uso comercial: https://www.paypal.me/a4grafica

Coki Fernández. Rosario, Argentina, Abril 2022.